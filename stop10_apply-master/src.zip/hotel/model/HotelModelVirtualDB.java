package hotel.model;

import java.util.ArrayList;

import hotel.model.dto.Guest;
import hotel.model.dto.OptionService;
import hotel.model.dto.Reservation;
import hotel.model.dto.Room;
import net.sf.json.JSONArray;

public class HotelModelVirtualDB {

	private static HotelModelVirtualDB instance = new HotelModelVirtualDB();
	private ArrayList<Reservation> reservationList = new ArrayList<Reservation>();

	private HotelModelVirtualDB() {

		reservationList.add(new Reservation("rsv201", new Guest("Lee", 31, "Madam", 3, 0, 0, "Normal"),
				new Room(201, "Delux", "Single"), new OptionService("notIncluded", "notIncluded", "notIncluded", "notIncluded")));
		reservationList.add(new Reservation("rsv301", new Guest("Park", 22, "Sir", 2, 8, 10, "Gold"),
				new Room(301, "Delux", "Twin"), new OptionService("notIncluded", "Included", "notIncluded", "notIncluded")));
		reservationList.add(new Reservation("rsv401", new Guest("Woo", 37, "Sir", 4, 4, 5, "Normal"),
				new Room(401, "Superior", "Queen"), new OptionService("notIncluded", "notIncluded", "notIncluded", "notIncluded")));
		reservationList.add(new Reservation("rsv501", new Guest("Kim", 51, "Madam", 3, 5, 21, "Platinum"),
				new Room(501, "Superior", "Queen"), new OptionService("notIncluded", "notIncluded", "Included", "Included")));
	}

	public static HotelModelVirtualDB getInstance() {
		return instance;
	}

	public ArrayList<Reservation> getReservationList() {
		return reservationList;
	}

	public void insertReservation(Reservation newReservation) {
		reservationList.add(newReservation);
	}

	public void deleteReservation(Reservation delReservation) {
		reservationList.remove(delReservation);
	}
	
	public JSONArray getJson() {
		JSONArray jsonArray = JSONArray.fromObject( reservationList );
		return jsonArray; 
	}
}
