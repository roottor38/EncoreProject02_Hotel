package hotel.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OptionService {

	private String Breakfast;
	private String Spa;
	private String FreeLounge;
	private String lateCheckOut;

	

}
